#ifndef PDcontroller_h
#define PDcontroller_h

class PDcontroller {
public:
  PDcontroller(float kp, float kd, double minOutput, double maxOutput);
  double update(double value, double target_value);

private:
  float _kp;
  float _kd;
  double _minOutput;
  double _maxOutput;
  double _lastError;
  long _previousTime;
};

#endif