#include "PDcontroller.h"
//#include <Pololu3piPlus32U4IMU.h>
#include <Arduino.h> // for millis()

// PD Controller constructor
PDcontroller::PDcontroller(float kp, float kd, double minOutput, double maxOutput)
  : _kp(kp), _kd(kd), _minOutput(minOutput), _maxOutput(maxOutput),
    _lastError(0.0), _previousTime(0) {}

// Main PD update logic
double PDcontroller::update(double value, double target_value) {
  double error = target_value - value;
  long currentTime = millis();
  double deltaTime = (currentTime - _previousTime) / 1000.0; // ms → seconds
  double derivative = 0.0;

  if (_previousTime != 0 && deltaTime > 0) {
    derivative = (error - _lastError) / deltaTime;
  }

  double output = _kp * error + _kd * derivative;

  // Constrain output within bounds
  if (output > _maxOutput) output = _maxOutput;
  if (output < _minOutput) output = _minOutput;

  // Save values for next loop
  _lastError = error;
  _previousTime = currentTime;

  return output;
}