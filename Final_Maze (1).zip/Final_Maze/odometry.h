#ifndef Odometry_h
#define Odometry_h

#include <Pololu3piPlus32U4.h>
#include <Wire.h>
using namespace Pololu3piPlus32U4;



class Odometry {
public:
  Odometry(float diaL, float diaR, float w, int nL, int nR, int gearRatio, bool dead_reckoning = false);
  void update_odom(int left_encoder_counts, int right_encoder_counts, float &x, float &y, float &theta);

private:
  float _x, _y, _theta;
  float _diaL, _diaR, _w;
  int _nL, _nR, _gearRatio;
  int _left_encoder_counts_prev;
  int _right_encoder_counts_prev;

  bool _deadreckoning;
  int _IMUavg_error;
  IMU _imu;
};

#endif