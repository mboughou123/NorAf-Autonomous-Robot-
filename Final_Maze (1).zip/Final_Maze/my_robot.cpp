#include <Pololu3piPlus32U4.h>
#include "my_robot.h"
using namespace Pololu3piPlus32U4;

extern Motors motors;

MyRobot::MyRobot(float base_speed) {
  _base_speed = base_speed / 1000.0; // cm/s converted for timing
}

// Stops both wheels full stop
void MyRobot::halt() {
  motors.setSpeeds(0, 0);
}

// Drives forward for given distance in cm
void MyRobot::forward(float distance) {
  float duration = (distance / _base_speed) * 1000.0; // ms
  motors.setSpeeds(int(_base_speed * 1000), int(_base_speed * 1000));

  unsigned long startTime = millis();
  while (millis() - startTime < duration);

  halt();
}

// Drives backward for given distance in cm
void MyRobot::backward(float distance) {
  float duration = (distance / _base_speed) * 1000.0;
  motors.setSpeeds(-int(_base_speed * 1000), -int(_base_speed * 1000));

  unsigned long startTime = millis();
  while (millis() - startTime < duration);

  halt();
}


// Wrapper: move forward one tile (10 cm)
void MyRobot::moveForwardOneTile() {
  forward(0.25);
  hasStarted = true; //tracks position only if it has started moving 
  // Update position based on direction. 
  switch (currentDirection) {
        case NORTH: robotY++; break;
        case EAST:  robotX++; break;
        case SOUTH: robotY--; break;
        case WEST:  robotX--; break;
    }

    motors.setSpeeds(0,0); // The robot stops here
}

// Wrapper: turn 90° left (adjust duration if needed)
//  Turns Left 90° (Accurate)
void MyRobot::turnLeft90() {
  motors.setSpeeds(-int(_base_speed * 1000), int(_base_speed * 1000));
  delay(1050);        //  Calibrated value 
  halt();
  updateDirectionLeft(); //  Updates direction
}

//  Turns Right 90° (Accurate)
void MyRobot::turnRight90() {
  motors.setSpeeds(int(_base_speed * 1000), -int(_base_speed * 1000));
  delay(1050);         //  Calibrated value 
  halt();
  updateDirectionRight(); //  Updates direction
}

// Manual motor speed override
void MyRobot::setSpeeds(int left, int right) {
  motors.setSpeeds(left, right);
}
// Updates the direction when turning left
void MyRobot::updateDirectionLeft() {
  switch (currentDirection) {
    case NORTH: currentDirection = WEST; break;
    case WEST:  currentDirection = SOUTH; break;
    case SOUTH: currentDirection = EAST; break;
    case EAST:  currentDirection = NORTH; break;
  }
}

// Updates the direction when turning right
void MyRobot::updateDirectionRight() {
  switch (currentDirection) {
    case NORTH: currentDirection = EAST; break;
    case EAST:  currentDirection = SOUTH; break;
    case SOUTH: currentDirection = WEST; break;
    case WEST:  currentDirection = NORTH; break;
  }
}
