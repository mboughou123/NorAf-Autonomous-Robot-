#include <Pololu3piPlus32U4.h>
#include <Pololu3piPlus32U4IMU.h>
#include "odometry.h"
#include "printOLED.h"
using namespace Pololu3piPlus32U4;

#define PI 3.14159

PrintOLED printOLED;

Odometry::Odometry(float diaL, float diaR, float w, int nL, int nR, int gearRatio, bool dead_reckoning)
  : _diaL(diaL), _diaR(diaR), _w(w), _nL(nL), _nR(nR),
    _gearRatio(gearRatio), _deadreckoning(dead_reckoning),
    _x(0), _y(0), _theta(0),
    _left_encoder_counts_prev(0), _right_encoder_counts_prev(0) 
{
  if (_deadreckoning) {
    Wire.begin();
    _imu.init();
    _imu.enableDefault();

    int total = 0;
    for (int i = 0; i < 100; i++) {
      _imu.readGyro();
      total += _imu.g.z;
      delay(1);
    }
    _IMUavg_error = total / 100;
  }
}

void Odometry::update_odom(int left_encoder_counts, int right_encoder_counts, float &x, float &y, float &theta) {
  double deltaL = ((left_encoder_counts - _left_encoder_counts_prev) * PI * _diaL) / (_nL * _gearRatio);
  double deltaR = ((right_encoder_counts - _right_encoder_counts_prev) * PI * _diaR) / (_nR * _gearRatio); 

  if (_deadreckoning) {
    _imu.readGyro();
    float angleRate = (_imu.g.z - _IMUavg_error);
    _theta += angleRate * 0.0001;
  } else {
    _theta += (deltaR - deltaL) / _w;
  }

  _x = ((deltaL + deltaR) / 2.0) * cos(_theta);
  _y = ((deltaL + deltaR) / 2.0) * sin(_theta);

  x += _x;
  y += _y;
  theta = _theta;

  printOLED.print_odom(x, y, theta);

  Serial.print("x: "); Serial.println(x);
  Serial.print("y: "); Serial.println(y);
  Serial.print("theta: "); Serial.println(theta);
  Serial.println("------------");

  _left_encoder_counts_prev = left_encoder_counts;
  _right_encoder_counts_prev = right_encoder_counts;
  delay(10);
}